class GenerationTestClass
{
    const b = 'bar';
    const a = 'foo';

    public $a;
    public $b;

    public function a()
    {
    }

    public function b()
    {
    }
}