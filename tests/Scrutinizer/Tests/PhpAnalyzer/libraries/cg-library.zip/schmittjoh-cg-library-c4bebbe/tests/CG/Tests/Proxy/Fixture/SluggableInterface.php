<?php

namespace CG\Tests\Proxy\Fixture;

interface SluggableInterface
{
    public function getSlug();
}
