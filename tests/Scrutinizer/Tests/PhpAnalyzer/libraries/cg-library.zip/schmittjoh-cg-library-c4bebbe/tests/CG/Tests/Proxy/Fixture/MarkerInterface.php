<?php

namespace CG\Tests\Proxy\Fixture;

interface MarkerInterface
{
}