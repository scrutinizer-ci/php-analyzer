<?php

// some PHP file
